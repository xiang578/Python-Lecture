from flask import Flask
app =Flask(__name__)

@app.route('/class')
def deep():
	return '<h1>Hello Class</h1>'

@app.route('/world')
def deep2():
	return '<h1>Hello World</h1>'

app.run(debug=True)