from flask import Flask,render_template
import json

app=Flask(__name__)
with open('bios.json')  as file:
	data=json.load(file)

@app.route('/persons')
def user():
	return render_template('13_4.html',data=data,itle="persons")

@app.route('/persons/<id>')
def user(id):
	return render_template('13_4_id.html',data=data,id=id)
	
app.run(debug=True)